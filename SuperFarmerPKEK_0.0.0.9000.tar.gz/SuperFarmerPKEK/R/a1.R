#'Zbior danych a1 zawiera wektor czasow dla 10 000 krotnego wywolania gry w SuperFarmer strategia SuperFarmerDA::strategia_maxrabbit.
#'Zbior danych stworzony w celu szybszego dzialania funkcji wizytowkaMEWA
#'
#'
#'
#'@name a1
#'@docType data
#'
NULL