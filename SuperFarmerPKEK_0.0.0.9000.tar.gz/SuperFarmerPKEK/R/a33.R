#'Zbior danych a1 zawiera wektor czasow dla 10 000 krotnego wywolania gry w SuperFarmer strategia SuperFarmerRCNK::strategia_yolo.
#'Zbior danych stworzony w celu szybszego dzialania funkcji wizytowkaMEWA
#'
#'
#'
#'@name a33
#'@docType data
#'
NULL