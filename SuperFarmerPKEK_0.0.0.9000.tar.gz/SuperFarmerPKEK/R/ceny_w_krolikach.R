#'Zbior zawierajacy domyslne wartosci zwierzat wyrazone w krolikach, zapisane jako nazwany wektor.
#'@name ceny_w_krolikach
#'
#'@docType data
#'
NULL