#'Zbior zawierajacy zwierzeta znajdujace sie na kostce nr 1.
#'@name kostka1
#'
#'@docType data
#'
NULL