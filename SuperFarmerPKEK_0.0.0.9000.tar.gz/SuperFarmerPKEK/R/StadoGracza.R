#'Zbior zawierajacy stan stada gracza, zapisany jako nazwany wektor.
#'@name StadoGracza
#'
#'@docType data
#'
NULL