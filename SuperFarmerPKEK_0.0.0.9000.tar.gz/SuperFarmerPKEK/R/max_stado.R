#'Zbior zawierajacy maksymalna liczbe zwierzat dostepna w grze, zapisana jako nazwany wektor.
#'@name max_stado
#'
#'@docType data
#'
NULL