#'Zbior zawierajacy zwierzeta znajdujace sie na kostce nr 2.
#'@name kostka2
#'
#'@docType data
#'
NULL