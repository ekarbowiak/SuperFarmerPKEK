test_that("Wynikiem funkcji gra jest liczba",{expect_is(gra(strategy1),"numeric")})

test_that("Wynikiem funkcji gra jest liczba",{expect_is(gra(strategy2),"numeric")})

test_that("Wynikiem funkcji gra jest liczba",{expect_is(gra(strategy3),"numeric")})
