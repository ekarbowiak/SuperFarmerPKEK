library(testthat)
library(SuperFarmerPKEK)



test_check("SuperFarmerPKEK")
